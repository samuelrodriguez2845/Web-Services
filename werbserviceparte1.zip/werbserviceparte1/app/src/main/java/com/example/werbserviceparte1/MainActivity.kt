package com.example.werbserviceparte1

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    private lateinit var mqttManager: MqttManager

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Inicializamos el gestor MQTT optimizado (sin requerir contexto)
        mqttManager = MqttManager()

        setContent {
            SmartCityDarkTheme {
                // Conexión segura dentro del ciclo de vida de la UI para evitar cierres
                LaunchedEffect(Unit) {
                    try {
                        mqttManager.connect()
                    } catch (e: Exception) {
                        e.printStackTrace()
                    }
                }
                SmartCityDashboard(mqttManager = mqttManager)
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        try {
            mqttManager.disconnect()
        } catch (e: Exception) {
            e.printStackTrace()
        }
    }
}

@Composable
fun SmartCityDarkTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = darkColorScheme(
            background = Color(0xFF0A0A0C),       // Negro espacial profundo
            surface = Color(0xFF141418),          // Gris grafito oscuro para tarjetas
            primary = Color(0xFF00FF66),          // Verde Neón brillante IoT
            secondary = Color(0xFF00E5FF),        // Cian tecnológico
            onBackground = Color(0xFFE2E8F0),     // Texto claro legible
            onSurface = Color(0xFFFFFFFF)         // Texto blanco puro
        ),
        content = content
    )
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SmartCityDashboard(mqttManager: MqttManager) {
    var isConnected by remember { mutableStateOf(false) }
    var currentTemperature by remember { mutableStateOf("-- °C") }
    var currentAirQuality by remember { mutableStateOf("Óptima") }
    var lightState by remember { mutableStateOf(false) }
    var alarmState by remember { mutableStateOf(false) }

    val messageLog = remember { mutableStateListOf<LogItem>() }
    val sdf = SimpleDateFormat("HH:mm:ss", Locale.getDefault())

    LaunchedEffect(Unit) {
        mqttManager.onConnectionChanged = { connected: Boolean ->
            isConnected = connected
        }
        mqttManager.onMessageReceived = { topic: String, payload: String ->
            val timeStr = sdf.format(Date())
            messageLog.add(0, LogItem(timeStr, topic, payload))

            if (topic.contains("temperatura")) {
                currentTemperature = "$payload °C"
            }

            // <-- ASEGÚRATE DE TENER ESTE BLOQUE EXACTO AQUÍ -->
            if (topic.contains("aire")) {
                currentAirQuality = payload
            }
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Cloud, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("SmartCity Monitor", fontWeight = FontWeight.Bold, fontSize = 18.sp, color = Color.White)
                            Text("IoT Node Live Stream", fontSize = 11.sp, color = Color.Gray)
                        }
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFF0A0A0C))
            )
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Tarjeta de Estado de Conexión Estilizada
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF26262C), RoundedCornerShape(16.dp))
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(12.dp)
                                .clip(CircleShape)
                                .background(if (isConnected) MaterialTheme.colorScheme.primary else Color.Red)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text("Broker MQTT (EMQX Cloud)", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = Color.White)
                            Text(if (isConnected) "Conectado en tiempo real" else "Reconectando al servidor...",
                                fontSize = 11.sp,
                                color = if (isConnected) MaterialTheme.colorScheme.primary else Color.Red)
                        }
                    }
                    Surface(
                        color = (if (isConnected) MaterialTheme.colorScheme.primary else Color.Red).copy(alpha = 0.1f),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Text(
                            text = if (isConnected) "ONLINE" else "OFFLINE",
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (isConnected) MaterialTheme.colorScheme.primary else Color.Red
                        )
                    }
                }
            }

            // Panel de Monitoreo (Suscripción)
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                SensorCard(
                    title = "Temperatura",
                    value = currentTemperature,
                    icon = Icons.Default.Thermostat,
                    accentColor = MaterialTheme.colorScheme.primary,
                    modifier = Modifier.weight(1f)
                )
                SensorCard(
                    title = "Calidad Aire",
                    value = currentAirQuality,
                    icon = Icons.Default.Air,
                    accentColor = MaterialTheme.colorScheme.secondary,
                    modifier = Modifier.weight(1f)
                )
            }

            // Panel de Control de Actuadores (Publicación)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .border(1.dp, Color(0xFF26262C), RoundedCornerShape(16.dp))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Text("Control de Actuadores Urbanos", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = MaterialTheme.colorScheme.primary)

                    // Control de Iluminación
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lightbulb, contentDescription = null, tint = if (lightState) Color.Yellow else Color.Gray, modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Iluminación Parque", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color.White)
                                Text("Tópico: actuadores/iluminacion", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                        Switch(
                            checked = lightState,
                            onCheckedChange = { newState ->
                                lightState = newState
                                val payload = if (newState) "ON" else "OFF"
                                mqttManager.publishMessage("smartcity/actuadores/iluminacion", payload)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = MaterialTheme.colorScheme.primary,
                                checkedTrackColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.3f),
                                uncheckedThumbColor = Color.Gray,
                                uncheckedTrackColor = Color(0xFF26262C)
                            )
                        )
                    }

                    HorizontalDivider(color = Color(0xFF26262C), thickness = 1.dp)

                    // Control de Alarma
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, tint = if (alarmState) Color.Red else Color.Gray, modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text("Alerta de Emergencia", fontSize = 13.sp, fontWeight = FontWeight.Medium, color = Color.White)
                                Text("Tópico: actuadores/alarma", fontSize = 10.sp, color = Color.Gray)
                            }
                        }
                        Switch(
                            checked = alarmState,
                            onCheckedChange = { newState ->
                                alarmState = newState
                                val payload = if (newState) "TRIGGER" else "STOP"
                                mqttManager.publishMessage("smartcity/actuadores/alarma", payload)
                            },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = Color.Red,
                                checkedTrackColor = Color.Red.copy(alpha = 0.3f),
                                uncheckedThumbColor = Color.Gray,
                                uncheckedTrackColor = Color(0xFF26262C)
                            )
                        )
                    }
                }
            }

            // Registro de Eventos (Logs en tiempo real)
            Text("Registro de Eventos MQTT", fontWeight = FontWeight.Bold, fontSize = 13.sp, color = Color.Gray)
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .border(1.dp, Color(0xFF26262C), RoundedCornerShape(16.dp))
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(messageLog) { log ->
                        Column(
                            modifier = Modifier
                                .fillMaxWidth()
                                .background(Color(0xFF0F0F13), RoundedCornerShape(10.dp))
                                .border(1.dp, Color(0xFF22222A), RoundedCornerShape(10.dp))
                                .padding(10.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(log.topic, fontSize = 11.sp, color = MaterialTheme.colorScheme.secondary, fontWeight = FontWeight.Bold)
                                Text(log.time, fontSize = 10.sp, color = Color.Gray)
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("Payload: ${log.payload}", fontSize = 12.sp, color = Color.White)
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SensorCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, accentColor: Color, modifier: Modifier = Modifier) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(16.dp),
        modifier = modifier.border(1.dp, Color(0xFF26262C), RoundedCornerShape(16.dp))
    ) {
        Column(
            modifier = Modifier.padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(28.dp)
                        .clip(RoundedCornerShape(6.dp))
                        .background(accentColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = accentColor, modifier = Modifier.size(16.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(title, fontSize = 12.sp, color = Color.Gray, fontWeight = FontWeight.Medium)
            }
            Text(value, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Color.White)
        }
    }
}

data class LogItem(val time: String, val topic: String, val payload: String)