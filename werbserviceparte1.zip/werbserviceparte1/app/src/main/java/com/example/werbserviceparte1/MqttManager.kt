package com.example.werbserviceparte1

import android.util.Log
import org.eclipse.paho.client.mqttv3.*
import org.eclipse.paho.client.mqttv3.persist.MemoryPersistence

class MqttManager {
    private val serverUri = "tcp://broker.emqx.io:1883"
    private val clientId = "SmartCityAndroidClient_" + System.currentTimeMillis()
    private val mqttClient: MqttClient = MqttClient(serverUri, clientId, MemoryPersistence())

    var onConnectionChanged: (Boolean) -> Unit = {}
    var onMessageReceived: (String, String) -> Unit = { _, _ -> }

    fun connect() {
        try {
            val options = MqttConnectOptions().apply {
                isAutomaticReconnect = true
                isCleanSession = true
                connectionTimeout = 10
                keepAliveInterval = 20
            }

            // Ejecutamos la conexión en un hilo secundario para cumplir con las políticas de red de Android
            Thread {
                try {
                    if (!mqttClient.isConnected) {
                        mqttClient.connect(options)
                        Log.i("MqttManager", "Conectado exitosamente al broker MQTT")
                        onConnectionChanged(true)

                        // --- AQUÍ AGREGAMOS LAS SUSCRIPCIONES A LOS SENSORES ---
                        subscribeToTopic("smartcity/sensores/temperatura")
                        subscribeToTopic("smartcity/sensores/aire")
                    }
                } catch (e: Exception) {
                    Log.e("MqttManager", "Fallo en la conexión MQTT: ${e.message}")
                    onConnectionChanged(false)
                }
            }.start()

            mqttClient.setCallback(object : MqttCallbackExtended {
                override fun connectComplete(reconnect: Boolean, serverURI: String?) {
                    Log.i("MqttCallback", "Conexión completada / Reconectado")
                    onConnectionChanged(true)
                }

                override fun connectionLost(cause: Throwable?) {
                    Log.w("MqttCallback", "Conexión perdida: ${cause?.message}")
                    onConnectionChanged(false)
                }

                override fun messageArrived(topic: String?, message: MqttMessage?) {
                    val payload = message?.toString() ?: ""
                    Log.d("MqttCallback", "Mensaje recibido en [$topic]: $payload")
                    if (topic != null) {
                        onMessageReceived(topic, payload)
                    }
                }

                override fun deliveryComplete(token: IMqttDeliveryToken?) {}
            })

        } catch (e: MqttException) {
            e.printStackTrace()
        }
    }

    private fun subscribeToTopic(topic: String, qos: Int = 1) {
        try {
            mqttClient.subscribe(topic, qos)
            Log.i("MqttManager", "Suscrito correctamente a: $topic")
        } catch (e: MqttException) {
            e.printStackTrace()
        }
    }

    fun publishMessage(topic: String, message: String, qos: Int = 1) {
        Thread {
            try {
                val mqttMessage = MqttMessage(message.toByteArray()).apply {
                    this.qos = qos
                }
                mqttClient.publish(topic, mqttMessage)
                Log.i("MqttManager", "Comando publicado en $topic -> $message")
            } catch (e: MqttException) {
                Log.e("MqttManager", "Error al publicar comando en $topic")
            }
        }.start()
    }

    fun disconnect() {
        try {
            if (mqttClient.isConnected) {
                mqttClient.disconnect()
                onConnectionChanged(false)
            }
        } catch (e: MqttException) {
            e.printStackTrace()
        }
    }
}